// End Semester Exam OS Lab

// Name: Sabyasachi Sarkar
// Roll No: 1901CS48

Question 1:
comands in terminal
	g++ 1.cpp -o 1
	./1

Question 2:
comands in terminal  
	g++ 2.cpp -o 2
	./2

Please enter the length of the sequence.
12
Please enter the page sequence.
0
1
5
3
0
1
4
0
1
5
3
4
Please enter the initial frame size.
3
Please enter the increased frame size.
4
# page faults for 3 frames =9
# page faults for 4 frames =10
Belady's anomaly detected.


Question 3:
	comands in terminal
	g++ 3.cpp -o 3
	./3
TLB hit ratio
0.9
Page table hit Ratio: 
0.99
TLB access time(ns) 
2
 Main memory acces time(ns)
50
Page Fault service time(ns)
10000
Effecrtfive memory accesss time: 67
